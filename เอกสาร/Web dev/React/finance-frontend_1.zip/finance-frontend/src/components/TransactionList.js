export default function TransactionList(props) {

  const generateRows = () => {
    if (props.data != null) {
      return props.data.map(transaction => (
        <tr bgColor={transaction.type === "income" ? 'green' : 'red'} key={transaction.id}>
          <td>{transaction.created}</td>
          <td>{transaction.type}</td>
          <td>{transaction.amount}</td>
          <td>
            <input value={transaction.note} onChange={evt => props.onNoteChanged(transaction.id, evt.target.value)}/>
          </td> 
          <td>
            <button onClick={() => props.onTransactionDeleted(transaction.id)}>ลบ</button>
          </td>
          {/* <td>
            <button onClick={() => alert(JSON.stringify(transaction))}>Debug</button>
          </td> */}
        </tr>
      ))
    }
    else {
      return null;
    }
  }

  return (
    <table border="1">
      <thead>
        <tr>
          <th>Date-Time</th>
          <th>Type</th>
          <th>Amount</th>
          <th>Note</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>{generateRows()}</tbody>
    </table>
  )
}
