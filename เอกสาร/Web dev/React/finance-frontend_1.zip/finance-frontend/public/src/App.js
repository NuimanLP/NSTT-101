import logo from './logo.svg';
import './App.css';
import moment from 'moment';
import TransactionList from './components/TransactionList';
import { useState, useEffect } from 'react';

function App() {

  const [transactionData, setTransactionData] = useState([
    { id: 1, created: "01/02/2023 - 08:30", type: "รายรับ", amount: 50000, note: "allowance" },
    { id: 2, created: "01/02/2023 - 10:30", type: "รายจ่าย", amount: 500, note: "อาหารเที่ยง" },
  ]);
  const [currentAmount ,setCurrentAmount] = useState(0)
  const [type, setType] = useState("รายรับ")
  const [amount, setAmount] = useState(0)
  const [note, setNote] = useState("")

  useEffect(() => {
    setCurrentAmount(
      transactionData.reduce(
      (sum, transaction) => sum = transaction.type === "รายรับ" ? sum + transaction.amount : sum - transaction.amount
      , 0)
    )
  }, [transactionData])
  
  const generateTransaction = () => {
    return {
      id: transactionData.length + 1,
      created: moment().format('DD/MM/YYYY - HH:mm'),
      type: type,
      amount: parseInt(amount),
      note: note,
    }
  }

  const onAddTransaction = () => {
    const newTransaction = generateTransaction();
    setTransactionData([...transactionData, newTransaction])
    setAmount(0)
    setNote("")
  }

  const handleNoteChanged = (id, note) => {
    setTransactionData(
      transactionData.map(transaction => {
        const newNote = transaction.id === id ? note : transaction.note;
        transaction.note = newNote
        return transaction
      })
    )
  }

  return (
    <div className="App">
      <header className="App-header">
        Current Amount {currentAmount}
        <select value={type} onChange={evt => setType(evt.target.value)}>
          <option value="รายรับ">รายรับ</option>
          <option value="รายจ่าย">รายจ่าย</option>
        </select>

        <input placeholder='จำนวนเงิน' value={amount} onChange={evt => setAmount(evt.target.value )}></input>
        <input placeholder='หมายเหตุ' value={note} onChange={evt => setNote(evt.target.value)}></input>

        <button onClick={onAddTransaction}>Add Transaction</button>
        <TransactionList data={transactionData} onNoteChanged={handleNoteChanged}/>
      </header>
    </div>
  );
}

export default App;
